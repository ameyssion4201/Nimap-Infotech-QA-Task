package com.demowebshop.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	WebDriver driver;
	
	@FindBy(linkText = "Log in")
	private WebElement Loginlink;
	
	@FindBy(id = "Email")
	private WebElement Email;
	
	@FindBy(id = "Password")
	private WebElement Password;
	
	@FindBy(css = "input.button-1.login-button")
	private WebElement loginbutton;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickLoginLink() {
		Loginlink.click();
	}
	
	public void loginUser(String email, String pwd) {
		Email.sendKeys(email);
		Password.sendKeys(pwd);
		loginbutton.click();
	}

}
