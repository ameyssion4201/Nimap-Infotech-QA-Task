package com.demowebshop.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchAndCartPage {
    WebDriver driver;

    // 1. Locators
    @FindBy(id = "small-searchterms")
    private WebElement searchInput;

    @FindBy(css = "input.button-1.search-box-button")
    private WebElement searchButton;

    // Product Title Link updated to generic xpath
    @FindBy(xpath = "//h2[@class='product-title']/a")
    private WebElement productLink;

    @FindBy(css = "input.button-1.add-to-cart-button")
    private WebElement addToCartButton;

    @FindBy(className = "ico-cart")
    private WebElement shoppingCartLink;

    // 2. Constructor
    public SearchAndCartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // 3. Actions
    public void searchProduct(String productName) {
        searchInput.sendKeys(productName);
        searchButton.click();
    }

    public void addProductToCart() {
        productLink.click();
        addToCartButton.click();
    }

    public void goToShoppingCart() {
        shoppingCartLink.click();
    }
}
