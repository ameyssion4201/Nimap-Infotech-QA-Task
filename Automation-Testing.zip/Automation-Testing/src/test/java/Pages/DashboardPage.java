package Pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DashboardPage {

    WebDriver driver;
    WebDriverWait wait;
    private By attendanceMenu = By.xpath("//span[contains(text(),'Attendance')] | //a[contains(.,'Attendance')]");
    private By addNewAttendanceBtn = By.xpath("//button[contains(.,'Add New')]");
    private By popupHeader = By.xpath("//h2 | //h3 | //h4 | //h5 | //div[contains(@class,'modal-title') or contains(@class,'toast') or @role='alert']");
    private By myCustomersMenu = By.xpath("//span[contains(text(),'My Customers')] | //a[contains(.,'My Customers')]");
    private By myCustomerSubMenu = By.xpath("//a[contains(.,'My Customer') and not(contains(.,'My Customers'))]");
    private By manageDropdownBtn = By.xpath("//button[contains(.,'Manage')]");
    private By newCustomerOption = By.xpath("//*[contains(text(),'New Customer')]");
    private By customerNameInput = By.xpath("//input[@placeholder='Enter Lead/Customer Name']");
    private By contactPersonInput = By.xpath("//input[@placeholder='Enter Contact Person Name']");
    private By mobileNoInput = By.xpath("//input[@placeholder='Enter Mobile No']");
    private By emailInput = By.xpath("//input[@placeholder='Enter Email']");
    private By cityInput = By.xpath("//input[@placeholder='Enter City']");
    private By saveBtn = By.xpath("//button[contains(.,'Save') or @type='submit']");

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    public String verifyPunchInToastOrPopup() {
        wait.until(ExpectedConditions.elementToBeClickable(attendanceMenu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(addNewAttendanceBtn)).click();
        WebElement popup = wait.until(ExpectedConditions.visibilityOfElementLocated(popupHeader));
        return popup.getText();
    }
    public boolean addAndValidateCustomer(String custName, String contactPerson, String mobile, String email, String city) throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(myCustomersMenu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(myCustomerSubMenu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(manageDropdownBtn)).click();
        wait.until(ExpectedConditions.elementToBeClickable(newCustomerOption)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(customerNameInput)).sendKeys(custName);
        driver.findElement(contactPersonInput).sendKeys(contactPerson);
        driver.findElement(mobileNoInput).sendKeys(mobile);
        driver.findElement(emailInput).sendKeys(email);
        driver.findElement(cityInput).sendKeys(city);

        WebElement save = wait.until(ExpectedConditions.presenceOfElementLocated(saveBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", save);
        
        Thread.sleep(2000);
        try {
            WebElement addedRecord = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//*[contains(text(),'" + custName + "') or contains(@class,'toast') or @role='alert']")));
            return addedRecord.isDisplayed();
        } catch (Exception e) {
            return driver.getCurrentUrl().contains("customers");
        }
    }
}
