package Pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    WebDriver driver;
    WebDriverWait wait;

    private By emailField = By.xpath("//input[@placeholder='Enter Email or Mobile Number']");
    private By passwordField = By.xpath("//input[@placeholder='Password']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void loginToApplication(String username, String password) {
        WebElement email = wait.until(ExpectedConditions.visibilityOfElementLocated(emailField));
        email.clear();
        email.sendKeys(username);

        WebElement pass = wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField));
        pass.clear();
        pass.sendKeys(password + Keys.ENTER);
    }
}
