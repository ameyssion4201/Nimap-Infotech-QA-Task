package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.LoginPage;
import Pages.DashboardPage;

public class FieldForceTest extends BaseTest {
    @DataProvider(name = "loginData")
    public Object[][] getLoginData() {
        return new Object[][] {
            { "amey04101997@outlook.com", "Ass@123", "Invalid" },
            { "amey04101997@gmail.com", "Amey@123", "Valid" }
        };
    }
    @DataProvider(name = "customerData")
    public Object[][] getCustomerData() {
        return new Object[][] {
            { "TechNova Solutions", "Rahul Patil", "9876543210", "rahul@technova.com", "Mumbai" }
        };
    }
    @Test(dataProvider = "loginData", priority = 1)
    public void verifyLoginJourney(String username, String password, String expectedResult) throws InterruptedException {
        driver.get("https://test.fieldforceconnect.com/auth/login");
        
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginToApplication(username, password);
        Thread.sleep(3000);

        if (expectedResult.equalsIgnoreCase("Valid")) {
            Assert.assertFalse(driver.getCurrentUrl().contains("login"), "Valid login failed!");
        } else if (expectedResult.equalsIgnoreCase("Invalid")) {
            Assert.assertTrue(driver.getCurrentUrl().contains("login"), "Invalid login should stay on login page!");
        }
    }
    @Test(priority = 2)
    public void verifyPunchInToast() throws InterruptedException {
        driver.get("https://test.fieldforceconnect.com/auth/login");
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginToApplication("amey04101997@gmail.com", "Amey@123");
        Thread.sleep(3000);

        DashboardPage dashboard = new DashboardPage(driver);
        String popupText = dashboard.verifyPunchInToastOrPopup();
        System.out.println("PunchIn Toast/Popup Message: " + popupText);
        Assert.assertFalse(popupText.isEmpty(), "Toast/Popup message was not displayed after PunchIn!");
    }
    @Test(dataProvider = "customerData", priority = 3)
    public void verifyAddCustomer(String custName, String contactPerson, String mobile, String email, String city) throws InterruptedException {
        driver.get("https://test.fieldforceconnect.com/auth/login");
        LoginPage loginPage = new LoginPage(driver);
        loginPage.loginToApplication("amey04101997@gmail.com", "Amey@123");
        Thread.sleep(3000);

        DashboardPage dashboard = new DashboardPage(driver);
        boolean isCustomerAdded = dashboard.addAndValidateCustomer(custName, contactPerson, mobile, email, city);
        Assert.assertTrue(isCustomerAdded, "Newly added customer was not found in the table!");
    }
}
