package Utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {
    
    public static ExtentReports extent;
    
    public static ExtentReports getReportsObject() {
        // Sets the destination directory path for storing the final HTML report
        String path = System.getProperty("user.dir") + "/TestNGReports.html";
        
        ExtentSparkReporter reporter = new ExtentSparkReporter(path);
        reporter.config().setReportName("Automation Test Report");
        reporter.config().setDocumentTitle("Selenium TestNG Report");
        
        extent = new ExtentReports();
        extent.attachReporter(reporter);
        
        // Configures fundamental system and environment parameters
        extent.setSystemInfo("Tester", "Amey");
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("Browser", "Chrome");
        
        return extent;
    }
}